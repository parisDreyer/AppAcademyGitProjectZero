class Simon
  COLORS = %w(red blue green yellow)

  attr_accessor :sequence_length, :game_over, :seq

  def initialize
    @sequence_length = 1
    @game_over = false
    @seq = []
  end

  def play
    take_turn until @game_over
    game_over_message
    reset_game
  end

  def take_turn
    if @game_over
      #game_over_message
    else
      require_sequence
      @sequence_length += 1
      show_sequence
      round_success_message
    end
  end

  def show_sequence(n = 1)
    add_random_color(n)
    @seq.dup[n..-1]
  end

  def require_sequence

  end

  def add_random_color(n = 1)
    n.times { @seq << COLORS.sample }
  end

  def round_success_message

  end

  def game_over_message

  end

  def reset_game
    @game_over = false
    @sequence_length = 1
    @seq = []
  end
end
